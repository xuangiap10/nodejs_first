import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-one',
  template: `
    <p>
      app-one: {{text}} (from parent)!
    </p>

  `,
  styles: [
  ]
})
export class OneComponent implements OnInit, OnChanges {
  @Input() text!: string;
  @Output() buttonClicked: EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
    //console.log('app-one OnInit is running');
  }
  ngOnChanges(changes: SimpleChanges): void {
    //console.log('app-one OnChanges', { changes });
  }

}
