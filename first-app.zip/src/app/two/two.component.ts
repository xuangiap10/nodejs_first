import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-two',
  template: `
    <p> </p>
    <button (click)="onButtonClicked()"> Button in app-two</button>
  `,
  styles: [
  ]
})
export class TwoComponent implements OnInit, OnChanges {
  @Input() text!: string;
  @Output() buttonClicked: EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
    //console.log('app-two OnInit is running');
  }
  ngOnChanges(changes: SimpleChanges): void {
    //console.log('app-two OnChanges', { changes });
  }
  onButtonClicked() {
    this.text = 'Click from app-two';
    this.buttonClicked.emit(this.text);
  }

}
