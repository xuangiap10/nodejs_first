import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div style="text-align:center" class="content">
      <h1>
        Welcome to {{title}}!
      </h1>
    </div>
    <app-two [text]="title" (buttonClicked)="onButtonClickedFromTwo($event)"></app-two>
    <app-one [text]="title"></app-one>
  `,
  styles: []
})
export class AppComponent implements OnInit, OnChanges {
  title = 'first-app';
  ngOnInit(): void {
    //console.log('app OnInit');
  }

  ngOnChanges(changes: SimpleChanges): void {
    //console.log('app OnChanges', { changes });
  }
  onButtonClick() {
    this.title = 'changed';
  }
  onButtonClickedFromTwo(event: string) {
    console.log({ event }, 'clicked from app-two');
    this.title = event;
  }
}
