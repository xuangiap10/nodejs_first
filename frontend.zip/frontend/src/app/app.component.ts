import { Component, inject } from '@angular/core';
import { IState } from './statesmodel';
import { Subscription } from 'rxjs';
import { StateService } from './state.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  state!: IState;
  subscription!: Subscription;
  private stateService = inject(StateService);
  constructor() {
    this.subscription = this.stateService.getState().subscribe(state => {
      this.state = state;
    });
  }
}
