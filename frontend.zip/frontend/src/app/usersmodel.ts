export interface IUser {
    _id: string,
    fullname: string,
    email: string,
    password: string
}

export interface Address {
    street: string,
    city: string,
    state: string,
    zipcode: number
}

export interface SignUpUser {
    _id: string,
    fullname: string,
    email: string,
    password: string,
    address: Address,
    phone: string,
    avatar: string
}
