import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { environment } from 'src/environments/environment';
import { IUser, SignUpUser } from './usersmodel';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private http = inject(HttpClient);
  login(data: IUser) {
    //send email/password to backend
    return this.http.post(environment.HTTP_SERVER + "/login", data);
  }
  signup(data: SignUpUser) {
    //add info to backend
    return this.http.post(environment.HTTP_SERVER + "/singup", data);
  }
  constructor() { }
}

