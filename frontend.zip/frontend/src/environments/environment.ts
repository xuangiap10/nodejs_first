export const environment = { HTTP_SERVER: 'http://localhost:3000' };
